from pathlib import Path
import datetime,fcntl,hashlib,json,os,subprocess,sys
root=Path('/Users/gchust/.t3/worktrees/NocoReach/fix-demo-reset-resource-nocoreach-20261029')
output=Path('/tmp/nocoreach-resource-formal-clean-20261029')
revision='f55023ac3b6e197a85d9bccb77f8146ddb27f643'
index=int(sys.argv[1]);assert index in [2,3]
order=['changed','base'] if index==2 else ['base','changed']
reference=json.loads((output/'pair-1/base/environment.json').read_text())
for name,digest in reference['harnessSha256'].items():
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
files=['server/nocoreach/demo-data/'+name+'.ts' for name in ['world/world','world/google','upstream','clear-all']]
originals={name:(output/'source-backup'/name.replace('/','_')).read_bytes() for name in files}
assert all((root/name).read_bytes()==data for name,data in originals.items())
base={name:subprocess.check_output(['git','show',f'{revision}:{name}'],cwd=root) for name in files}
pair=output/f'pair-{index}';pair.mkdir(exist_ok=True);assert not list(pair.iterdir())
print(f'Pair {index} explicitly released by coordinator; queued at {datetime.datetime.now(datetime.timezone.utc).isoformat()}',flush=True)
with open('/tmp/demo-reset-resource-benchmark.lock','a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 print(f'Pair {index} acquired resource lock',flush=True)
 try:
  result={'baseRevision':revision,'order':order,'exitCodes':{}}
  for label in order:
   for name,data in (base if label=='base' else originals).items(): (root/name).write_bytes(data)
   run=subprocess.run(['python3','tests/nocoreach/resource/run.py',str(pair/label)],cwd=root,env={**os.environ,'DEMO_RESOURCE_LOCK_FD':str(lock.fileno())},pass_fds=(lock.fileno(),))
   result['exitCodes'][label]=run.returncode
  (pair/'pair.json').write_text(json.dumps(result,indent=2))
 finally:
  for name,data in originals.items(): (root/name).write_bytes(data)
print(f'Pair {index} released resource lock; no further pair queued',flush=True)
print(json.dumps(result,indent=2),flush=True)
