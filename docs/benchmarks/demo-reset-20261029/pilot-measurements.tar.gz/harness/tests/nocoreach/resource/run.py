#!/usr/bin/env python3
"""Run the full-app resource test in a fresh process under a shared host lock."""
import fcntl
import json
import os
from pathlib import Path
import platform
import re
import signal
import subprocess
import sys
import time
import tempfile
import hashlib

root = Path(__file__).resolve().parents[3]
out = Path(sys.argv[1]).resolve()
out.mkdir(parents=True, exist_ok=True)
with open('/tmp/demo-reset-resource-benchmark.lock', 'a') as lock:
    print('Waiting for shared benchmark lock', flush=True)
    fcntl.flock(lock, fcntl.LOCK_EX)
    scratch = tempfile.TemporaryDirectory(prefix='nocoreach-resource-')
    env = {**os.environ, 'TMPDIR': scratch.name, 'DEMO_RESOURCE_TEST': '1', 'DEMO_RESOURCE_RESULT': str(out / 'result.json'), 'NOCOREACH_DEMO_AGENT_PACE': '0'}
    env.pop('NODE_OPTIONS', None)
    command = ['node', 'node_modules/vitest/vitest.mjs', 'run', 'tests/nocoreach/demo-reset-resource.test.ts', '--maxWorkers=1', '--disableConsoleIntercept', '--execArgv=--expose-gc', '--execArgv=--trace-gc-nvp', '--execArgv=--max-old-space-size=1536']
    metadata = {'command': command, 'node': subprocess.check_output(['node', '-v'], text=True).strip(), 'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(), 'platform': platform.platform(), 'machine': platform.machine(), 'cpuCount': os.cpu_count(), 'lock': lock.name, 'startedAt': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
    assert metadata['node'] == 'v24.22.1', metadata['node']
    metadata['harnessSha256'] = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__).resolve(), root / 'tests/nocoreach/demo-reset-resource.test.ts']}
    metadata['sourceSha256'] = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((root / 'server/nocoreach/demo-data').rglob('*.ts'))}
    metadata['lockfileSha256'] = hashlib.sha256((root / 'pnpm-lock.yaml').read_bytes()).hexdigest()
    if sys.platform == 'darwin':
        metadata['hardware'] = subprocess.check_output(['sysctl', 'hw.model', 'hw.memsize', 'machdep.cpu.brand_string'], text=True).strip()
    (out / 'environment.json').write_text(json.dumps(metadata, indent=2))
    start = time.monotonic()
    with open(out / 'raw.log', 'w') as log:
        process = subprocess.Popen(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            code = process.wait(timeout=2100)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
            code = 124
    scratch.cleanup()
    raw = (out / 'raw.log').read_text()
    gc_peak = max([int(v) for v in re.findall(r'(?:total_size_before|start_object_size)=(\d+)', raw)] or [0])
    metadata.update(exitCode=code, elapsedSeconds=time.monotonic() - start, gcObservedPeakHeap=gc_peak)
    (out / 'environment.json').write_text(json.dumps(metadata, indent=2))
    complete = (out / 'result.json').exists() and json.loads((out / 'result.json').read_text()).get('complete')
    print(json.dumps(metadata, indent=2), flush=True)
    # A missing result, crash, timeout or an observed heap over budget fails closed.
    sys.exit(0 if code == 0 and complete and gc_peak > 0 and gc_peak < 900 * 1024 ** 2 else 1)
